export default function HomePage() {
  return <h1>Hello from Next.js!</h1>;
}
